import './assets/main.css'

import { createApp } from 'vue'
import { createPinia } from 'pinia'

import App from './App.vue'
import router from './router'

//PLUGINS
import vuetify from './plugins/Vuetify'
import globalComponents from './plugins/GlobalComponents'
import './plugins/Luxon'
import i18n from './i18n'

const app = createApp(App).use(i18n)

//PLUGINS
app.use(globalComponents)
app.use(vuetify)

//PROJECT BASE
app.use(createPinia())
app.use(router)

app.mount('#app')
