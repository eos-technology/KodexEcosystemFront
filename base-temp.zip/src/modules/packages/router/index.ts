const packagesRoutes = {
    path: '/packages',
    name: 'packages',
    meta: {
        requiresAuth: false
    },
    children: [
{
    path: 'create',
    name: 'create',
    component: () => import ('@/modules/packages/views/create/Index.vue')
},
{
    path: 'edit',
    name: 'edit',
    component: () => import ('@/modules/packages/views/edit/Index.vue')
},
{
    path: 'delete',
    name: 'delete',
    component: () => import ('@/modules/packages/views/delete/Index.vue')
},
{
    path: 'transfer',
    name: 'transfer',
    component: () => import ('@/modules/packages/views/transfer/Index.vue')
}
    ]
}

export default packagesRoutes
