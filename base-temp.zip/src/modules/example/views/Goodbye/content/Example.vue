<template>
  <h2>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti provident reprehenderit rerum
    temporibus optio harum cum minus commodi, eaque pariatur? Aliquam obcaecati sequi repellendus
    odit iure ducimus eum, earum nulla?
  </h2>
</template>
