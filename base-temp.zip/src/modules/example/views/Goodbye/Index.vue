<template>
  <!-- //HTML CONTENT -->
  <Example />
</template>

<script setup lang="ts">
import Example from './content/Example.vue'
import { useExampleStore } from '../../store/exampleStore'
let exampleStore = useExampleStore()

import { ref, computed, watch } from 'vue'

// Definición de propiedades
const props = defineProps(['messageFromParent'])

// Propiedad reactiva
let count: any = ref(0)

// Computed property
const message = computed(() => props.messageFromParent + ' desde el componente')

// Métodos
const incrementCount = () => {
  let api = exampleStore.getRequest().then((response: any) => {
    count = response
  })
  count.value++
}

// Watcher
watch(
  () => count.value,
  (newCount, oldCount) => {
    console.log(`El contador cambió de ${oldCount} a ${newCount}`)
  }
)
</script>

<style lang="scss"></style>
