<template>
  //HTML CONTENT
  <p style="font-size: 30px; color: white">
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum optio nostrum placeat repellat
    pariatur doloremque maiores odit dignissimos illum ullam, rem eligendi doloribus illo accusamus
    a nulla explicabo aperiam dolore!
  </p>
</template>
<script setup lang="ts"></script>
