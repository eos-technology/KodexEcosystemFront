const exampleRoutes = {
  path: '/example',
  name: 'example',
  meta: {
    requiresAuth: false
  },
  children: [
    {
      path: 'Hello',
      name: 'Hello',
      component: () => import('@/modules/example/views/Hello/Index.vue')
    },
    {
      path: 'Goodbye',
      name: 'Goodbye',
      component: () => import('@/modules/example/views/Goodbye/Index.vue')
    }
  ]
}

export default exampleRoutes
