import { defineStore } from 'pinia'
import { makeRequest } from '../helpers'
// project imports

export const useExampleStore = defineStore({
  id: 'card',
  state: (): any => ({}),
  getters: {},
  actions: {
    async getRequest(params?: any) {
      try {
        const data: any = await makeRequest({ route: 'endpointExample', params })
        return data.data
      } catch (error) {
        return error
      }
    }
  }
})
