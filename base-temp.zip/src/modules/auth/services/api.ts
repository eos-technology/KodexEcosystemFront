import type { Endpoint } from '../types/serviceTypes'

const api: Record<string, Endpoint> = {
  endpointExample: {
    method: 'post',
    uri: function (params?: any) {
      return `carts/${params}`
    }
  },
  loginRequest: {
    method: 'post',
    uri: function () {
      return '/auth/login'
    }
  }
}

export default api
