<template>
  //HTML CONTENT
  <h2 style="color: white">FRONT REU</h2>
  <div>
    <Form @submit="onLogin" v-slot="{ isSubmitting }">
      <v-text-field :rules="rules.email" placeholder="Inicio de sesión" />
      <v-text-field :rules="rules.password" placeholder="Contraseña" type="password" />
      <v-btn :loading="isSubmitting" color="primary">Iniciar sesión</v-btn>
    </Form>
  </div>
</template>
<script setup lang="ts">
import { Form } from 'vee-validate'
import { reactive } from 'vue'

const rules = reactive({
  email: [(v: string) => !!v || 'Password is required'],
  password: [
    (v: string) => !!v || 'Password is required',
    (v: string) => (v && v.length <= 10) || 'Password must be less than 10 characters'
  ]
  // Puedes agregar más reglas aquí...
})

const onLogin = () => {}
</script>
