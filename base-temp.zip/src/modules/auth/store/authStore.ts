import { defineStore } from 'pinia'
import { makeRequest } from '../helpers'
import type { loginType } from '../types/storeTypes'
// project imports

export const useAuthStore = defineStore({
  id: 'auth',
  state: (): any => ({}),
  getters: {},
  actions: {
    async login(params?: any) {
      try {
        const data: loginType = await makeRequest({ route: 'endpointExample' })
        return data.bearer
      } catch (error) {
        return error
      }
    }
  }
})
