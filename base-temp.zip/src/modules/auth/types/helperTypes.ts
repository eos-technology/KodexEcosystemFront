export type requestType = {
  route: string
  params?: any
  body?: any
}
