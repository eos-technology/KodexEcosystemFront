export type loginType = {
  bearer: String
}
